import sys
import os
import io
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QFileDialog, QMessageBox, QFrame, QScrollArea, QLineEdit
from PyQt5.QtGui import QFont
from PyQt5.QtCore import Qt, QThread, pyqtSignal
from moviepy import VideoFileClip
from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseUpload
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
import pickle

class VideoConverter(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()
        self.drive_service = self.authenticate_google_drive()

    def initUI(self):
        self.setWindowTitle('Video Converter')
        self.setGeometry(100, 100, 900, 600)
        self.setStyleSheet("""
            @import url('https://fonts.googleapis.com/css2?family=Tektur:wght@400;700&display=swap');
            * {
                font-family: 'Tektur', sans-serif;
                font-size: 18px;
            }
            QLabel {
                color: white;
            }
            QLineEdit, QPushButton {
                background-color: #334155;
                color: white;
                border: 1px solid #475569;
                padding: 15px;
                border-radius: 10px;
            }
            QPushButton {
                background-color: #3b82f6;
            }
            QFrame {
                background-color: #334155;
                color: white;
                border: 1px solid #475569;
                padding: 15px;
                border-radius: 10px;
            }
        """)
        self.setStyleSheet("background-color: #1e293b; color: white;")

        main_layout = QVBoxLayout()

        title = QLabel('ZIMA TEAM')
        title.setFont(QFont('Tektur', 48, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(title)

        file_selection_layout = QHBoxLayout()

        browse_button = QPushButton('Выбрать файлы', self)
        browse_button.setStyleSheet("background-color: #475569; color: white; padding: 15px; border-radius: 10px;")
        browse_button.setFixedWidth(200)  # Set a fixed width to make it the same size as the directory button
        browse_button.clicked.connect(self.browse_files)
        file_selection_layout.addWidget(browse_button)

        self.file_paths_label = QLabel('Файлы не выбраны', self)
        self.file_paths_label.setStyleSheet("background-color: #334155; color: white; border: 1px solid #475569; padding: 10px; border-radius: 10px;")
        self.file_paths_label.setFixedHeight(60)  # Set a fixed height to make it smaller
        file_selection_layout.addWidget(self.file_paths_label)

        main_layout.addLayout(file_selection_layout)

        separator = QFrame()
        separator.setFrameShape(QFrame.HLine)
        separator.setFrameShadow(QFrame.Sunken)
        separator.setStyleSheet("color: white;")
        main_layout.addWidget(separator)


        output_dir_layout = QHBoxLayout()

        select_dir_button = QPushButton('Выбрать директорию', self)
        select_dir_button.setStyleSheet("background-color: #475569; color: white; padding: 15px; border-radius: 10px;")
        select_dir_button.setFixedWidth(200)  # Set a fixed width to make it the same size as the file button
        select_dir_button.clicked.connect(self.select_output_directory)
        output_dir_layout.addWidget(select_dir_button)

        self.output_dir_label = QLabel('Директория для сохранения не выбрана', self)
        self.output_dir_label.setStyleSheet("background-color: #334155; color: white; border: 1px solid #475569; padding: 10px; border-radius: 10px;")
        self.output_dir_label.setFixedHeight(60)
        output_dir_layout.addWidget(self.output_dir_label)

        main_layout.addLayout(output_dir_layout)


        naming_convention_layout = QHBoxLayout()

        self.naming_convention_input = QLineEdit(self)
        self.naming_convention_input.setPlaceholderText('Введите название файла')
        self.naming_convention_input.setStyleSheet("background-color: #334155; color: white; border: 1px solid #475569; padding: 15px; border-radius: 10px;")
        self.naming_convention_input.setFixedHeight(60)
        naming_convention_layout.addWidget(self.naming_convention_input)

        main_layout.addLayout(naming_convention_layout)

        self.scroll_area = QScrollArea(self)
        self.scroll_area.setWidgetResizable(True)
        self.scroll_content = QWidget(self.scroll_area)
        self.scroll_layout = QVBoxLayout(self.scroll_content)
        self.scroll_area.setWidget(self.scroll_content)
        main_layout.addWidget(self.scroll_area)


        format_layout = QHBoxLayout()
        self.format_buttons = {}
        for format in ['mp4', 'mov', 'avi', 'mpeg', 'mkv']:
            button = QPushButton(format.upper(), self)
            button.setStyleSheet("background-color: #475569; color: white; padding: 15px; border-radius: 10px;")
            button.clicked.connect(lambda checked, f=format: self.set_format(f))
            format_layout.addWidget(button)
            self.format_buttons[format] = button
        main_layout.addLayout(format_layout)

        self.estimated_size_label = QLabel('', self)
        main_layout.addWidget(self.estimated_size_label)

        self.progress_label = QLabel('', self)
        main_layout.addWidget(self.progress_label)

        convert_button = QPushButton('Конвертировать', self)
        convert_button.setStyleSheet("background-color: #3b82f6; color: white; padding: 15px; border-radius: 10px;")
        convert_button.clicked.connect(self.convert_videos)
        main_layout.addWidget(convert_button)

        convert_drive_button = QPushButton('Сохранить в Google Drive', self)
        convert_drive_button.setStyleSheet("background-color: #3b82f6; color: white; padding: 15px; border-radius: 10px;")
        convert_drive_button.clicked.connect(self.convert_videos_to_drive)
        main_layout.addWidget(convert_drive_button)

        self.setLayout(main_layout)

    def authenticate_google_drive(self):
        SCOPES = ['https://www.googleapis.com/auth/drive.file']
        creds = None
        if os.path.exists('token.pickle'):
            with open('token.pickle', 'rb') as token:
                creds = pickle.load(token)
        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                creds.refresh(Request())
            else:
                flow = InstalledAppFlow.from_client_secrets_file('credentials.json', SCOPES)
                creds = flow.run_local_server(port=0)
            with open('token.pickle', 'wb') as token:
                pickle.dump(creds, token)
        return build('drive', 'v3', credentials=creds)

    def set_format(self, format):
        self.selected_format = format
        for f, button in self.format_buttons.items():
            if f == format:
                button.setStyleSheet("background-color: #3b82f6; color: white; padding: 15px; border-radius: 10px;")
            else:
                button.setStyleSheet("background-color: #475569; color: white; padding: 15px; border-radius: 10px;")

    def browse_files(self):
        options = QFileDialog.Options()
        file_paths, _ = QFileDialog.getOpenFileNames(self, "Выберите видео файлы", "", "All Files (*);;Video Files (*.avi *.mkv *.mov *.flv)", options=options)
        if file_paths:
            self.file_paths = file_paths
            self.file_paths_label.setText('\n'.join(file_paths))
            self.display_video_info(file_paths)

    def display_video_info(self, file_paths):
        try:
            total_size = 0
            for i in reversed(range(self.scroll_layout.count())):
                widgetToRemove = self.scroll_layout.itemAt(i).widget()
                self.scroll_layout.removeWidget(widgetToRemove)
                widgetToRemove.setParent(None)

            for file_path in file_paths:
                clip = VideoFileClip(file_path)
                duration = clip.duration
                resolution = clip.size
                file_size = os.path.getsize(file_path) / (1024 * 1024)  # Convert to MB
                total_size += file_size

                file_info_frame = QFrame(self)
                file_info_frame.setStyleSheet("background-color: #334155; color: white; border: 1px solid #475569; padding: 15px; border-radius: 10px; margin-bottom: 10px;")
                file_info_layout = QVBoxLayout(file_info_frame)
                file_info_layout.addWidget(QLabel(f"Название файла: {os.path.basename(file_path)}"))
                file_info_layout.addWidget(QLabel(f"Разрешение: {resolution[0]}x{resolution[1]}"))
                file_info_layout.addWidget(QLabel(f"Длительность: {duration:.2f} секунд"))
                file_info_layout.addWidget(QLabel(f"Размер: {file_size:.2f} MB"))
                self.scroll_layout.addWidget(file_info_frame)

            self.estimated_size_label.setText(f"Общий предполагаемый размер файла: {total_size:.2f} MB")
        except Exception as e:
            self.info_label.setText(f"Error: {e}")

    def select_output_directory(self):
        directory = QFileDialog.getExistingDirectory(self, "Выберите директорию для сохранения")
        if directory:
            self.output_dir = directory
            self.output_dir_label.setText(directory)

    def convert_videos(self):
        if not hasattr(self, 'file_paths') or not self.file_paths:
            QMessageBox.warning(self, "Ошибка", "Пожалуйста, выберите видео файлы.")
            return

        if not self.selected_format:
            QMessageBox.warning(self, "Ошибка", "Пожалуйста, выберите формат.")
            return

        if not hasattr(self, 'output_dir') or not self.output_dir:
            QMessageBox.warning(self, "Ошибка", "Пожалуйста, выберите директорию для сохранения.")
            return

        naming_convention = self.naming_convention_input.text()
        if not naming_convention:
            QMessageBox.warning(self, "Ошибка", "Пожалуйста, введите название файла.")
            return

        self.progress_label.setText('')
        self.thread = ConversionThread(self.file_paths, self.selected_format, self.output_dir, naming_convention, self.drive_service, save_to_drive=False)
        self.thread.progress.connect(self.update_progress)
        self.thread.finished.connect(self.conversion_finished)
        self.thread.start()

    def convert_videos_to_drive(self):
        if not hasattr(self, 'file_paths') or not self.file_paths:
            QMessageBox.warning(self, "Ошибка", "Пожалуйста, выберите видео файлы.")
            return

        if not self.selected_format:
            QMessageBox.warning(self, "Ошибка", "Пожалуйста, выберите формат.")
            return

        naming_convention = self.naming_convention_input.text()
        if not naming_convention:
            QMessageBox.warning(self, "Ошибка", "Пожалуйста, введите название файла.")
            return

        self.progress_label.setText('')
        self.thread = ConversionThread(self.file_paths, self.selected_format, None, naming_convention, self.drive_service, save_to_drive=True)
        self.thread.progress.connect(self.update_progress)
        self.thread.finished.connect(self.conversion_finished)
        self.thread.start()

    def update_progress(self, value, total, index):
        progress_percentage = (value / total) * 100
        progress_bar = '█' * int(progress_percentage / 10) + ' ' * (10 - int(progress_percentage / 10))
        self.progress_label.setText(f"Прогресс конвертации: {progress_percentage:.0f}%|{progress_bar}| {value}/{total} (Файл {index + 1}/{len(self.file_paths)})")

    def conversion_finished(self):
        QMessageBox.information(self, "Успех", "Все видео успешно конвертированы!")

class ConversionThread(QThread):
    progress = pyqtSignal(int, int, int)

    def __init__(self, file_paths, selected_format, output_dir, naming_convention, drive_service, save_to_drive):
        super().__init__()
        self.file_paths = file_paths
        self.selected_format = selected_format
        self.output_dir = output_dir
        self.naming_convention = naming_convention
        self.drive_service = drive_service
        self.save_to_drive = save_to_drive

    def run(self):
        for index, input_path in enumerate(self.file_paths):
            output_path = os.path.join(self.output_dir, f"{self.naming_convention}_{index + 1}.{self.selected_format}") if self.output_dir else f"{self.naming_convention}_{index + 1}.{self.selected_format}"
            try:
                clip = VideoFileClip(input_path)
                total_frames = int(clip.fps * clip.duration)
                for frame_index, frame in enumerate(clip.iter_frames()):
                    # Simulate frame processing
                    self.progress.emit(frame_index + 1, total_frames, index)
                clip.write_videofile(output_path, codec='libx264')
                if self.save_to_drive:
                    self.upload_to_google_drive(output_path)
            except Exception as e:
                QMessageBox.critical(None, "Ошибка", f"Произошла ошибка при конвертации видео {os.path.basename(input_path)}: {e}")

            self.progress.emit(total_frames, total_frames, index)

    def upload_to_google_drive(self, file_path):
        file_metadata = {'name': os.path.basename(file_path)}
        media = MediaIoBaseUpload(io.FileIO(file_path, 'rb'), mimetype='video/mp4')
        self.drive_service.files().create(body=file_metadata, media_body=media, fields='id').execute()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    converter = VideoConverter()
    converter.show()
    sys.exit(app.exec_())